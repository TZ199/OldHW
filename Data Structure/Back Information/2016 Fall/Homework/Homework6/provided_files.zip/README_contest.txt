HOMEWORK 6: PAINT BY PAIRS CONTEST


NAME:  < insert name >



COLLABORATORS AND OTHER RESOURCES:
< insert collaborators / resources >



DESCRIPTION OF ANY PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:
(please be concise!)



DESCRIBE INTERESTING NEW PUZZLES YOU CREATED:



SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
# of solutions & approximate wall clock running time for different
puzzles for a single solution or all solutions.
