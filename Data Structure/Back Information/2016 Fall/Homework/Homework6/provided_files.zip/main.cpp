#include <iostream>
#include <fstream>
#include <cassert>
#include <cstdlib>

#include "board.h"


int main(int argc, char* argv[]) {

  // parse the arguments
  if (argc < 2) {
    std::cerr << "USAGE:  " << argv[0] << " <puzzlefile>" << std::endl;
    std::cerr << "        " << argv[0] << " <puzzlefile> find_all_solutions" << std::endl;
    exit(0);
  }
  bool all_solutions = false;
  if (argc > 2) {
    assert (argc == 3);
    assert (std::string(argv[2]) == std::string("find_all_solutions"));
    all_solutions = true;
  }

  // open the file
  std::ifstream istr(argv[1]);
  if (!istr.good()) {
    std::cerr << "ERROR!  cannot open " << argv[1] << std::endl;
    exit(0);
  }

  // read the file
  std::string token;
  istr >> token;
  assert (token == "width");
  int width,height;
  istr >> width;
  istr >> token;
  assert (token == "height");
  istr >> height;
  assert (width > 0);
  assert (height > 0);
  int x,y,v;

  // create the board
  Board board(width,height);
  while (istr >> x >> y >> v) {
    assert (x >= 0 && x < width);
    assert (y >= 0 && y < height);
    board.set(x,y,v);
  }

  // print the original puzzle board
  std::cout << board;

  // Now...  solve it!

}



