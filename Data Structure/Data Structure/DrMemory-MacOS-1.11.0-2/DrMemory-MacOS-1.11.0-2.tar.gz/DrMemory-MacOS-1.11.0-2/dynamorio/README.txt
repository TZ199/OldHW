This is a copy of the parts of DynamoRIO needed to run Dr. Memory.  See http://dynamorio.org for more information.
