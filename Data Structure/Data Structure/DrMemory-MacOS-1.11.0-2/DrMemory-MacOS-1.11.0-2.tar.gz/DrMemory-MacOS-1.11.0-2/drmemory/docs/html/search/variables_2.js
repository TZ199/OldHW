var searchData=
[
  ['default_5fvalue',['default_value',['../struct__umbra__map__options__t.html#a67f5c4ec38915115cac514bbf0e3eb85',1,'_umbra_map_options_t']]],
  ['default_5fvalue_5fsize',['default_value_size',['../struct__umbra__map__options__t.html#a75acf08a8ca3a8481bfbb088566e0404',1,'_umbra_map_options_t']]],
  ['drcontext',['drcontext',['../struct__drsys__arg__t.html#a85e6af373eaf287bc9682ce219ec3dba',1,'_drsys_arg_t']]]
];
