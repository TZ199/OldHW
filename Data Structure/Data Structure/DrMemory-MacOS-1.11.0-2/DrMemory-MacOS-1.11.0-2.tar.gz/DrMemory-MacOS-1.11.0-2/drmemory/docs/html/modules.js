var modules =
[
    [ "Dr. Syscall: System Call Monitoring Extension", "group__drsyscall.html", "group__drsyscall" ],
    [ "Umbra: DynamoRIO Shadow Memory Extension", "group__umbra.html", "group__umbra" ],
    [ "Dr. Fuzz: DynamoRIO Fuzz Testing Extension", "group__drfuzz.html", "group__drfuzz" ],
    [ "Dr. SymCache: Symbol Lookup Cache Extension", "group__drsymcache.html", "group__drsymcache" ],
    [ "Dr. Memory Framework", "group__drmf.html", "group__drmf" ]
];