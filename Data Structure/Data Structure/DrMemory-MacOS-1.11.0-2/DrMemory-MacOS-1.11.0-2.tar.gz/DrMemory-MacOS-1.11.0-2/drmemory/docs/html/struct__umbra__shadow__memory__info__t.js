var struct__umbra__shadow__memory__info__t =
[
    [ "app_base", "struct__umbra__shadow__memory__info__t.html#a88b0d289e81fc0977c6d91f46ec7ea3f", null ],
    [ "app_size", "struct__umbra__shadow__memory__info__t.html#ab60f038191d648429beec20da4bf40c7", null ],
    [ "shadow_base", "struct__umbra__shadow__memory__info__t.html#ac050e28c324a7929a4426a22dd0fb177", null ],
    [ "shadow_size", "struct__umbra__shadow__memory__info__t.html#ae9d7b9776e1f1719c9b7665d59859ecf", null ],
    [ "shadow_type", "struct__umbra__shadow__memory__info__t.html#a1b3f97e7a5f6f058f70e912af79c5189", null ],
    [ "struct_size", "struct__umbra__shadow__memory__info__t.html#a1ade90e0b9c9d0a26debc41500151ec7", null ]
];