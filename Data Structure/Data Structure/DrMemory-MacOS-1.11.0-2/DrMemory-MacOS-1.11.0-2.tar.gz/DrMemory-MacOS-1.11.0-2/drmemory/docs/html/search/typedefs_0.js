var searchData=
[
  ['app_5fmemory_5fcreate_5fcb_5ft',['app_memory_create_cb_t',['../group__umbra.html#ga2d2b65225bc91de41cc4e715723fb1bc',1,'umbra.h']]]
];
