var searchData=
[
  ['umbra_5fcreate_5fshadow_5fshared_5freadonly',['UMBRA_CREATE_SHADOW_SHARED_READONLY',['../group__umbra.html#ggaa49d0c1fffdb93fdfd0db1278b1eaad9a6fbe76f298c0201ce92a4427a7805687',1,'umbra.h']]],
  ['umbra_5fmap_5fcreate_5fshadow_5fon_5ftouch',['UMBRA_MAP_CREATE_SHADOW_ON_TOUCH',['../group__umbra.html#ggaaa9d16970f73407af0af6b173afd62b6a16bca8c68c5e970c4457b64606a9671b',1,'umbra.h']]],
  ['umbra_5fmap_5fscale_5fdown_5f2x',['UMBRA_MAP_SCALE_DOWN_2X',['../group__umbra.html#gga670274c9cd812c91317125c7179cb15aa362e915faa295d0503c9815bac7d5a58',1,'umbra.h']]],
  ['umbra_5fmap_5fscale_5fdown_5f4x',['UMBRA_MAP_SCALE_DOWN_4X',['../group__umbra.html#gga670274c9cd812c91317125c7179cb15aa70662a2ec93fd7702942d5f473ade106',1,'umbra.h']]],
  ['umbra_5fmap_5fscale_5fsame_5f1x',['UMBRA_MAP_SCALE_SAME_1X',['../group__umbra.html#gga670274c9cd812c91317125c7179cb15aa30e49a70fa05e2ff43b7c4b436199e29',1,'umbra.h']]],
  ['umbra_5fmap_5fscale_5fup_5f2x',['UMBRA_MAP_SCALE_UP_2X',['../group__umbra.html#gga670274c9cd812c91317125c7179cb15aa257a8fc2cc1cd3516a317510a47148ca',1,'umbra.h']]],
  ['umbra_5fmap_5fshadow_5fshared_5freadonly',['UMBRA_MAP_SHADOW_SHARED_READONLY',['../group__umbra.html#ggaaa9d16970f73407af0af6b173afd62b6ae42e8acda254c7bf3a3b196d070a284d',1,'umbra.h']]],
  ['umbra_5fshadow_5fmemory_5ftype_5fnormal',['UMBRA_SHADOW_MEMORY_TYPE_NORMAL',['../group__umbra.html#gga218086740fc30ca9ec82ad9e1a8f94d0a0c8cdfdebf602f0c39c581c229dffe6f',1,'umbra.h']]],
  ['umbra_5fshadow_5fmemory_5ftype_5fnot_5fshadow',['UMBRA_SHADOW_MEMORY_TYPE_NOT_SHADOW',['../group__umbra.html#gga218086740fc30ca9ec82ad9e1a8f94d0a9757d1da5b2a5c95fb57ee2883cdfec1',1,'umbra.h']]],
  ['umbra_5fshadow_5fmemory_5ftype_5fshadow_5fnot_5falloc',['UMBRA_SHADOW_MEMORY_TYPE_SHADOW_NOT_ALLOC',['../group__umbra.html#gga218086740fc30ca9ec82ad9e1a8f94d0a254f60164a8f40da3f6598d5e6015833',1,'umbra.h']]],
  ['umbra_5fshadow_5fmemory_5ftype_5fshared',['UMBRA_SHADOW_MEMORY_TYPE_SHARED',['../group__umbra.html#gga218086740fc30ca9ec82ad9e1a8f94d0a4401ff2d8bd1c4f5e5274b3a251bf413',1,'umbra.h']]],
  ['umbra_5fshadow_5fmemory_5ftype_5funknown',['UMBRA_SHADOW_MEMORY_TYPE_UNKNOWN',['../group__umbra.html#gga218086740fc30ca9ec82ad9e1a8f94d0aef9152f543316d474bf454114e8d57fa',1,'umbra.h']]]
];
