var searchData=
[
  ['lookup_5finternal_5fsymbol',['lookup_internal_symbol',['../struct__drsys__options__t.html#a2ef1bc5d546d8e4888ca97596ca6df6c',1,'_drsys_options_t']]],
  ['license_20for_20dr_2e_20memory',['License for Dr. Memory',['../page_license.html',1,'']]],
  ['light_20mode',['Light Mode',['../page_light.html',1,'']]]
];
