var struct__drfuzz__fault__thread__state__t =
[
    [ "fault_count", "struct__drfuzz__fault__thread__state__t.html#a4908e6ada56ae113148f5c7d9abd224e", null ],
    [ "faults", "struct__drfuzz__fault__thread__state__t.html#a0f43ba34f1817e2d34e94f0f9310d85a", null ],
    [ "faults_observed", "struct__drfuzz__fault__thread__state__t.html#a8c30fe265d497a36565e9755e1b88385", null ],
    [ "targets", "struct__drfuzz__fault__thread__state__t.html#abfc05b2473d60e526f007a4a1968a603", null ],
    [ "thread_id", "struct__drfuzz__fault__thread__state__t.html#a7b3cc2056d660a583c244eabf7e235eb", null ]
];