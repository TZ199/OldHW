var struct__umbra__map__options__t =
[
    [ "app_memory_create_cb", "struct__umbra__map__options__t.html#a9886fb5b988987a4918a61464bb85b2a", null ],
    [ "app_memory_mremap_cb", "struct__umbra__map__options__t.html#ae61776cf0d015757e3c84a68fd33d3e1", null ],
    [ "app_memory_post_delete_cb", "struct__umbra__map__options__t.html#a1ebeed9022c5c8980df16b08bf838b3d", null ],
    [ "app_memory_pre_delete_cb", "struct__umbra__map__options__t.html#a404a50e702bafcb14fdc33084aeebdef", null ],
    [ "default_value", "struct__umbra__map__options__t.html#a67f5c4ec38915115cac514bbf0e3eb85", null ],
    [ "default_value_size", "struct__umbra__map__options__t.html#a75acf08a8ca3a8481bfbb088566e0404", null ],
    [ "flags", "struct__umbra__map__options__t.html#aaafc8da2e9f63676968b6d869b6ca8bb", null ],
    [ "scale", "struct__umbra__map__options__t.html#a57948f438b0fc0495efee78389d132b1", null ],
    [ "struct_size", "struct__umbra__map__options__t.html#a023efc50dbc6de67efc3b39547f4cebb", null ]
];