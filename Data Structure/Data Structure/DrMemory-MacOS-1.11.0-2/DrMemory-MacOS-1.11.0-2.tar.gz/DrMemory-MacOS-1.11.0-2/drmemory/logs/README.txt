Default destination for log files.
