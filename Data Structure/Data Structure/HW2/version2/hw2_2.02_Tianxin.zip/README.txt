HOMEWORK 2: LEAGUE OF LEGENDS CLASSES


NAME:  < Tianxin Zhou >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Class notes >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 7 >



DESCRIPTION OF 3RD STATISTIC: 
Please be clear & concise!  What is your hypothesis for the creation
of this statistic?

My hypothesis is the player who get the highest DKr may not be the player who dominate the late game. And some player may not perform good. In early game, but do well in late game.
So I create a statistic to find the player who is most powerful in late game.
My definition of late game is: after 20 mins.

RESULTS FROM 3RD STATISTIC:
Paste in a small amount of sample output into this file, or list the
file names of sample input & output included with your submisssion.
Describe what is interesting about your statistic on this data.
Please be concise!

The partial output for custom: (using the input_medium)

PLAYER NAME            KILLS  DEATHS     LATEKILLS   PLAYED WITH CHAMPION(S)
AquaNova                  22       6            19   Ahri
Yoreo                     29       8            18   Rengar, Sivir
guardianForceX            20      11            12   Malphite, Zed
Schaibs                   24       9            10   Sivir
EzXin                     14       5            10   Maokai
Agatroth15862             15       6             9   Lucian
D0odleBob                 14       7             9   Nidalee
DibsOnVayne               13       7             9   Nasus, Vayne
Coriolis                  15       6             8   Volibear
Hebs                      10       9             8   Fiddlesticks
ChinatownStreet           12       2             7   Riven
Ind0                      12       6             7   LeBlanc
GODVA                     12       8             7   Ahri
OOSalty                    9       4             7   Ryze
JrBatman                   7      10             7   Heimerdinger
ERAQAQAQAR                14      13             6   Ezreal
XianJin                   12       8             6   Zed
Eskuhmoh                   9       7             6   LeBlanc

The partial output from players(using the input_medium):
PLAYER NAME            KILLS  DEATHS     KDR   PLAYED WITH CHAMPION(S)
S2MaRtin                   9       1    9.00   Maokai
nisanasa                   8       1    8.00   Nidalee
ImyourMaryJane             7       1    7.00   Riven
ChinatownStreet           12       2    6.00   Riven
SoundArc                   6       0    6.00   Volibear
KentaroOe                  5       0    5.00   Jax
Obi1conknowbe              5       1    5.00   Jinx
jockerZK                   4       0    4.00   Graves
AquaNova                  22       6    3.67   Ahri
Yoreo                     29       8    3.62   Rengar, Sivir
DrJackel                   7       2    3.50   Ezreal, Orianna
Calliee                    3       0    3.00   Lulu
Aykachan                   3       1    3.00   Jax
TheAlmightyDigRa           3       1    3.00   Amumu
EzXin                     14       5    2.80   Maokai
Schaibs                   24       9    2.67   Sivir
Agatroth15862             15       6    2.50   Lucian
Coriolis                  15       6    2.50   Volibear

Than we find the interesting thing: 
The player who get the highest DKr may not be the player who dominate the late game.
Some players like AquaNova only got 3 kills in first 20 mins, but got 19 kills after 20mins.

MISC. COMMENTS TO GRADER:  
Optional, please be concise!

