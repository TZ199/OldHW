HOMEWORK 2: LEAGUE OF LEGENDS CLASSES


NAME:  < Tianxin Zhou >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Class notes >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 7 >



DESCRIPTION OF 3RD STATISTIC: 
Please be clear & concise!  What is your hypothesis for the creation
of this statistic?



RESULTS FROM 3RD STATISTIC:
Paste in a small amount of sample output into this file, or list the
file names of sample input & output included with your submisssion.
Describe what is interesting about your statistic on this data.
Please be concise!


MISC. COMMENTS TO GRADER:  
Optional, please be concise!

