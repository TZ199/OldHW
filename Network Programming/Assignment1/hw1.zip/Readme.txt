Readme
Assignment 1
Group of Tianxin Zhou and Haoming Li.
Service name:Guess
Compile command: gcc hw1_main.c hw1_handle.c
Running command: ./a.out
On another terminal: dns-sd -L "Guess" _gtn._tcp local
telnet localhost portnumber.
Resources consulted: test2.c, test5.c, select.c, code chunk on piazza.